package com.project.springweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectCrudOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.project.springweb;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;

@RestController
@RequestMapping("api")
@CrossOrigin("http://localhost:8080")
public class ProductController {

	@Autowired
	SessionFactory sessionFactory;

	List<Product> productList = null;

	@SuppressWarnings({ "unchecked", "deprecation" })
	@GetMapping("products")
	public List<Product> getAllProducts() {

		Session session = sessionFactory.openSession();

		productList = session.createCriteria(Product.class).list();

		return productList;

	}

	@GetMapping("product/{id}")
	public Product getProduct(@PathVariable int id) {

		Session session = sessionFactory.openSession();

		Product product = session.load(Product.class, id);

		return product;
	}

	@PostMapping("product/{categoryid}")
	public String addProduct(@RequestBody Product product, @PathVariable int categoryid) {

		Session session = sessionFactory.openSession();

		Category category = session.load(Category.class, categoryid);

		System.out.println(categoryid);

		productList = category.getProduct();

		Transaction transaction = session.beginTransaction();

		productList.add(product);

		transaction.commit();

		return "Product added";
	}

	@SuppressWarnings({ "deprecation", "unchecked" })
	@PutMapping("product")
	public String updateProduct(@RequestBody Product product) {

		Session session = sessionFactory.openSession();

		Transaction transaction = session.beginTransaction();

		session.update(product);

		transaction.commit();

		productList = session.createCriteria(Product.class).list();

		return "Product data updated";
	}

	@DeleteMapping("product/{id}")
	public String deleteProduct(@PathVariable int id) {

		Session session = sessionFactory.openSession();

		Transaction transaction = session.beginTransaction();

		Product deleteProduct = session.load(Product.class, id);

		session.delete(deleteProduct);

		transaction.commit();
		
//		Session session = sessionFactory.openSession();
//		
//		NativeQuery<Object[]> nativeQuery = session.createSQLQuery("category.category_id, category.category_name from category, product where product.category_id=category.category_id and product.product_id="+id);
//
//		List<Object []> list = nativeQuery.list();
//		
//		System.err.println(list);
//		
//		Object [] array = list.get(0);
//		
//		int cid = (int) array[0];
//		
//		Category category = session.load(Category.class, cid);
//		
//		List<Product> prodList = category.getProduct();
//		
//		Product product = session.load(Product.class, id);
//		
//		Transaction transaction = session.beginTransaction();
//		
//		session.delete(product);
//		
//		transaction.commit();
		
		return "Product deleted";
	}
	
	
}

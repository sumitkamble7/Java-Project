package com.project.springweb;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("http://localhost:8080")
@RequestMapping("api")
public class CategoryController {

	@Autowired
	SessionFactory sessionFactory;

	List<Category> categoryList = null;

	@SuppressWarnings({ "unchecked", "deprecation" })
	@GetMapping("categories")
	public List<Category> getAllCategories() {

		Session session = sessionFactory.openSession();

		categoryList = session.createCriteria(Category.class).list();

		return categoryList;
	}

	@GetMapping("category/{id}")
	public Category getCategory(@PathVariable int id) {

		Session session = sessionFactory.openSession();

		Category category = session.load(Category.class, id);

		return category;
	}

	@SuppressWarnings({ "deprecation", "unchecked" })
	@PostMapping("category")
	public String addNewCategory(@RequestBody Category category) {

		Session session = sessionFactory.openSession();

		Transaction transaction = session.beginTransaction();

		session.save(category);

		transaction.commit();

		categoryList = session.createCriteria(Category.class).list();

		return "New category added";
	}

	@SuppressWarnings({ "deprecation", "unchecked" })
	@PutMapping("category")
	public String updateCategory(@RequestBody Category category) {

		Session session = sessionFactory.openSession();

		Transaction transaction = session.beginTransaction();

		session.update(category);

		transaction.commit();

		categoryList = session.createCriteria(Category.class).list();
		return "Category updated";
	}

	@DeleteMapping("category/{id}")
	public String deleteCategory(@PathVariable int id) {

		Session session = sessionFactory.openSession();

		Category deleteCategory = session.load(Category.class, id);

		Transaction transaction = session.beginTransaction();

		session.delete(deleteCategory);

		transaction.commit();

		return "Category deleted";
	}
}
